function sayHello(){
    alert('Hello!!!!');
}
let bb= document.getElementById('clickButton');
bb.onclick =function(){
    alert('Hello World');
}
function createPElement(){
    let pEle = document.createElement('p');
    pEle.textContent ='This is p Element';
    document.body.appendChild(pEle);
}

let alertElement = document.getElementById('alertHi');
alertElement.addEventListener('click',function(){
    alert ('good evening');
});

let he = document.createElement('h1');
function showText(){
  let ie =document.getElementById('showData');
  console.log(ie.value);
 he.textContent =ie.value;
document.body.appendChild(he);
}