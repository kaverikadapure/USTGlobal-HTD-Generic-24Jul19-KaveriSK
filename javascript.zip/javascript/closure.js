function sum(a,b){
    function addSum(){
        return a+b;
    }
    return addSum;
}
var addFunc = sum(10,20);
var total = addFunc();
console.log('total=',total);
console.log(window);
console.log(this);
console.log(this==window);
var name= 'kavi';
console.log(window.name);
console.log(this.name);

var person = {
     name : 'abcd',
     age : 12,
     getname : function(){
         console.log(this);
         console.log(window);
         getData();
         function getData(){
             console.log('get data method',this.name);
         }
      return this.name;

     }
}
var heroname = person.getname();
console.log('name ='+heroname);
console.log("----");

for( i=0;i<5;i++)
{
    console.log(i);
}
console.log('i='+i);

for(let j=0;j<5;j++)
{
    console.log(j);
}
//console.log('j=',j);
console.log("----");

var hobbies = ['dancing','singing','cooking'];
console.log('hobbies = '+hobbies);
var hobbies =['numismatics'];
console.log('hobbies = '+hobbies);
hobbies = ['singing'];

console.log("----");

let fruits =['orange','mango'];
console.log('fruits = '+fruits);
fruits =['apple'];
console.log('fruits = '+fruits);

console.log("-----");
const hobbie =['singing','dancing','cooking'];
console.log('hobbie='+hobbie);
hobbie[0] =['gardening'];
console.log(hobbie);


