var hobbies = ['singing', 'dancing', 'cricket', 'football'];
hobbies.forEach(function (myhobbies, index)
{
    if(myhobbies.length>7)
    console.log('hobbies ='+myhobbies);
});
console.log(myhobbies);