let n = 5;
const f=1;
{
 for(i=1;i<=n;i++)
 {
     f=f*i
 }
}
console.log(f);