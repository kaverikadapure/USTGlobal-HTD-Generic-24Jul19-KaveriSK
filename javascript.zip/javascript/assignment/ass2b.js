//factorial
function fact(n)
{
   if(n==0)
   {
       return 1;
   }
   else
   {
        return n*fact(n-1);
   }
}
let factorial = fact(5);
console.log('factorial=',factorial);


//fibonacci series
var fib = function(n)
{
    if(n==1)
    {
        return[0,1];
    }
    else
    {
        var num = fib(n-1);
        num.push(num[num.length-1]  + num[num.length-2]);
        return num;
    }
};
console.log('fibonacci series =',fib(4));

// circumference
function circle(radius)
{
    this.radius=radius;
    this.circumference =function()
    {
        return 2*Math.PI * this.radius;
    };
}
var circum = new circle(4);
console.log('circumference of circle =',circum.circumference().toFixed(2));

//aum of array elements
 array= [10,20,30,40];
sum = 0;
for(i=0;i<array.length; i++)
{
    sum += array[i];
}
console.log('sum of array elements=',sum);

//checking a number is prime or not
function prime(n)
{
    p=0;
    for(i=2;i<=n;i++)
    {
        if(n%2==0)
        {
            p=1;
        }
    }
    if(p==0)
    {
        console.log('given number is prime');
    }
    else
    {
        console.log('given number is not prime');
    }
}
console.log(prime(88));