function addtotable()
            {
                var table = document.getElementById("table"),
                newRow =table.insertRow(table.length),
                
                cell1 =newRow.insertCell(0),
                cell2 =newRow.insertCell(1),
                cell3 =newRow.insertCell(3),
               
                fname = document.getElementById("fname").value,
                lname = document.getElementById("lname").value,
                age = document.getElementById("age").value;

                cell1.innerHTML = fname;
                cell2.innerHTML = lname;
                cell3.innerHTML = age;
                
            }