console.log('-----------array methods---------');
// usimg forEach
var fruits = ['apple', 'mango', 'grapes', 'melon'];
fruits.forEach(function (fruit, index)
{
    if(fruit.length>5)
    console.log('fruits =',fruit);
});
console.log(fruits);

//is array 
var fruits = ['apple', 'mango', 'grapes', 'melon'];
var ans = Array.isArray(fruits);
console.log('is array' ,ans);

//includes
var r= fruits.includes('mango',0);
console.log('include=' ,r);

//push
fruits.push('orange');
console.log('push=' +fruits);

//pop
fruits.pop();
console.log('pop = ' +fruits);

//unshift
fruits.unshift('strawberry');
console.log('unshift list= ' +fruits);

//shift
fruits.shift();
console.log('shift list= ' +fruits);

//splice
fruits.splice(1,1,'jamun');
console.log('spliced list= ' +fruits);

//slice
var d= fruits.slice(1,3);
console.log('sliced list= ' ,d);

//join
fruits.join('-');
console.log('join list = ' +fruits);

//indexof
var s = fruits.indexOf('jamun',1);
console.log('indexOf jamun = ' ,s);

//push
var num = [10,20,30,40];
var nw = [ ];
for(var i=0; i<num.length; i++)
{
    nw.push(num[i]+2);
}
console.log('pushed list = ' +num);

//map
var num = [10,20,30,40];
var nums = num.map(function(value,index)
{
    var t= value+2;
    return t;
});
console.log(nums);

console.log('-----------strings methods---------')

//toLowerCase
var t2 = 'KAVERI';
var t2res = t2.toLowerCase();
console.log( 'lowercase = ' ,t2res);

//toUpperCase
var t1 = 'kaveri';
var tres = t1.toUpperCase();
console.log('uppercase= ' ,tres);

//extracting the string by using charAt//
var str = "Hello World";
var d = str.charAt(2);
console.log('charAt = ',d);

//extracting the string by using indexOf//
var str = "Please locate where locates occurs";
var p = str.indexOf("locate", 2);
console.log('indexOf = ' ,p);

//concatenation
var t1 = 'butter';
var t2 = 'fly';
var res = t1.concat('' , t2);
console.log('concate = ' ,res);

//includees
var str = "this is a long string of words";
var s = str.includes('long',1);
console.log('includes = ' ,s);

//replace
str = "My name is kavi";
console.log(str);
res = str.replace('kavi','kaveri');
console.log('replace = ' ,res);

//split
var str ='HELLO';
var r = str.split('E',3);
console.log('split = ' ,r);

//substr method
var str = "lavender";
var rs = str.substr(1,4);
console.log('substr = ' ,rs);

//search
var txt = "ABCDEFGHIJKLMN";
var srch = ('F');
console.log('search = ' ,srch);

//extracting the string by using String.trim
var str = "  Hello world";
alert(str.trim());
console.log('trim = ',alert);

