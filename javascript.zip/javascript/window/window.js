window.alert('hello');
alert('Hello world');
let isAdult = confirm('are you Adult?');
console.log('is Adult ='+isAdult);
let name = prompt('what is your name?');
console.log('name='+name);