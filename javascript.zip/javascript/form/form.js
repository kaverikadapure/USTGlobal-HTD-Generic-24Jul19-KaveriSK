function validateForm()
{
  let formData =  document.forms[0];
  //console.log(formData.uname.value);
  let Username = formData.uname.value;
  let Password= formData.pw.value;
  if(Username.length>4 && Password.length>7)
  {
     // console.log('Success');
      formData.uname.style.border = '1px solid green';
      formData.pw.style.border = '1px solid green';
      formData.loginSubmit.disabled = false;
  }
  else
  {
      formData.uname.style.border = '4px solid red';
      formData.pw.style.border = '4px solid red';
      formData.loginSubmit.disabled = true;
  }
}

/*function validateForm1(){
    let formData =  document.forms[0];
    console.log(formData.pw.value);
    let Password = formData.pw.value;
  if(Password.length>7)
  {
    console.log('Success');
    formData.pw.style.border = '4px solid green';
  }
  else
  {
    formData.pw.style.border = '4px solid red';
  }
}
