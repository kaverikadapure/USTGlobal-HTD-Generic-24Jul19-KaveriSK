function validate()
{
   let ed =  document.forms['employeeForm'];
   let ep = ed.pass.value;
   let ecp = ed.cpass.value;
  if(ep==='' && ecp==='' )
  {
      return false;
  }
   else if (ep == ecp) 
   {
       alert('success');
       return true;
   }
   else
   {
        alert('Password not matching');
        return false;
   }
}