let n1 = [1,2,3,4];
//let n2=0;
n1.forEach(function (n2, i)
{
    for(i=0; i<n1.length; i++)
    {
        n2 = (n2+n1[i]);
       // i--;
    }
    console.log('sum of array ='+n2);
});

