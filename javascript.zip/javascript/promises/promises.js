let employeeData = new Promise(function(resolve,reject)
{
  const emp = [
      {
   name : 'khrithik',
   age : 50
      },
      {
        name : 'ranbeer',
        age : 30
        },
        {
            name : 'ritu',
            age : 40
        }
];
    if(10>10)
 {
     reject('Failed');
 }
 else
 {
     resolve (emp);
 }
});
employeeData.then((Data)=>{
    //console.log('employee data =',Data);
    return Data;
}).catch((error)=>{
    console.log('catch block='+error);
}).then(function(data){
    console.log('this is then block2',data);
});