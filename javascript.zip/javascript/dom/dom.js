let p1 = document.getElementById('demo');
console.log(p1);
p1.textContent = 'this is new p tag';

let p2 = document.getElementsByClassName('blue');
console.log(p2);

let p3 = document.getElementsByTagName('p');
console.log(p3);

let p4 = document.getElementsByName('helement');
console.log(p4);

let p5 = document.querySelector('#demo');
console.log(p5);

let p6 =document.querySelectorAll('.blue');
console.log(p6);

let p7 = document.createElement('button');
p7.textContent = 'Click Me'; 
console.log(p7);

document.body.appendChild(p7);
console.log('---------------------------');

let s =document.getElementById('p7');
span.style.color = 'red';
let p7= document.getElementById(p7);
p7.className='add';
p7.classList= 'add add1';

let e= document.getElementById('demo1');
//e.style.color ='blue';
//e.className ='blue';
e.classlist ='blue fonts';