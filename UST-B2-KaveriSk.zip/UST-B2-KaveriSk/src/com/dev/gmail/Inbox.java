package com.dev.gmail;

public class Inbox {
	
	public int Meassage_Id;
	public int User_Id;
	public String Message;
	
	public int getMeassage_Id() {
		return Meassage_Id;
	}
	public void setMeassage_Id(int meassage_Id) {
		Meassage_Id = meassage_Id;
	}
	public int getUser_Id() {
		return User_Id;
	}
	public void setUser_Id(int user_Id) {
		User_Id = user_Id;
	}
	public String getMessage() {
		return Message;
	}
	public void setMessage(String message) {
		Message = message;
	}
	
	
}
