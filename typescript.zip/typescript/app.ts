/// <reference path="./circle.ts" />
/// <reference path="./rectangle.ts" />

MathOperation.Circle.circum(8);
MathOperation.rectangle.area(7,4);



//let myName = 'kaveri';
//console.log(myName);
//let company;
//company ='testyantra';
//console.log(company);
//company = 22;
//console.log(company);

//let sample : number | boolean;
//sample = 10;
//sample = true;
//let myArray : string [] = ['shgjsh','dgd'];
//console.log(myArray);
//let myTuple : [string, number, boolean] = ['aeesfg', 22, true];
//console.log(myTuple);

//enum colors{
   // red ='danger',
    //blue = 'better',
    //green = 'good'
//}
//console.log(colors.blue);

//class Person {
 //name : string ;
 //age : number ;
 //constructor(public nm:string, public ag:number)
 //{
     //this.name=nm;
     //this.age=ag;
 //}
//}

//let p= new Person ('kavi',22);
//console.log(p.nm);
//console.log(p.ag);

// let myName = ' kavi';
// myName = null;

// interface Student {
//     name : string;
//     age : number;
//     printdetails (): void;
// }
  
// class Person implements Student{
//     name ='mangu';
//     age = 25;
//     printdetails(){
//         console.log("name is" +this.name);
//     }
// }

// let person2 = new Person;
// person2.printdetails();

// let student1 : Student = {
//     name : 'kavi',
//     age : 25,
//     printdetails : () => {
//         console.log("name is= "+this.name + 'age is'+student1.age);
//     }

// }

// function getArray<p>(items:p[]):p[]{
//     return new Array<p>().concat(items);
// }

// let strArray = getArray<string>(['abc','pqr','xyz'];
// let numArray = getArray<number>([111,222,333]);
// numArray.push(444);
// console.log(numArray);

