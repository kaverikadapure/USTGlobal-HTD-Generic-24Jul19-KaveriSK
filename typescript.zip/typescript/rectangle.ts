namespace MathOperation {
    export namespace rectangle{
    export function area(length : number, breadth : number){
        console.log('area='+length+breadth);
    }
    export function perimeter(length : number, breadth : number){
        console.log("perimeter = "+ 2*length*breadth)
    }
}
}
