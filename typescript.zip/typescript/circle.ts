namespace MathOperation{
    export namespace Circle{
    const PI = 3.14;
    export function circum(radius : number){
        console.log("circumference = "+2*PI*radius);
    }
    export function area(radius : number){
        console.log("arera = "+PI*radius*radius);
    }
    }
}
//  MathOperations.circum(2);
//  MathOperations.area(4);