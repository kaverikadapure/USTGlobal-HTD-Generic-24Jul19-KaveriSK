package com.dev.thread;

public class Thread5 extends Thread {
	
	
	Printer1 p1;
	
	
	public Thread5(Printer1 po) {
		p1 = po;
	}


	@Override
	public void run() {
		try {
			Thread.currentThread().sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		p1.showString("Method From second Printer");
	}
}
