package com.dev.thread;

public class MainThreadClass {

	public static void main(String[] args) {
	System.out.println("Main Thread started");
	
	System.out.println("MainThreadClass  pritns the value for i");
	
	Thread2 t2 =new Thread2();
	t2.setName("Thread T2");
	t2.setPriority(6);
	t2.start();
	
	//new  T2().start(); 
	
	Thread3 t = new Thread3();
	Thread tt = new Thread(t);
	tt.setPriority(2);
	tt.start();
	
	Thread.currentThread().setName("Main Thread");
	
	//new Thread(new T3()).start();
	
	for(int i=1; i<=10; i++) {
		System.out.println("i = "+i);
	}
	System.out.println("Thread Name: "+t2.getName());
	System.out.println("Thread Name: "+Thread.currentThread().getName());
	System.out.println("Thread2 id : "+t2.getId());
	System.out.println("Thread2 p : "+t2.getPriority());
	System.out.println("Thread3 id : "+tt.getId());
	System.out.println("Thread3 p : "+tt.getPriority());
	System.out.println("Main Thread id : "+Thread.currentThread().getId());
	
	System.out.println("Main Thread end");
	}

}
