package com.dev.thread;

public class Test {
	public static void main(String[] args) {
		System.out.println("Main Thread start");
		
		for(int i=1; i<=20; i++) {
			System.out.println("i = "+i);
		}
		
		for(int i=1; i<=10; i++) {
			System.out.println("i = "+i);
		}
		
		System.out.println("Main Thread end");
		}

}
