package com.dev.thread;

public class Printer1 {
 synchronized public void showString(String s) {
	System.out.println("string = "+s);
}
}
