package com.dev.abstraction;

public class MarkerInterface {

}
