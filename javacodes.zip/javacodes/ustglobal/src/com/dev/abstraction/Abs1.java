package com.dev.abstraction;

public class Abs1 implements Abs {

	@Override
	public void display() {
		System.out.println("display method of interface");
	}
	
	public static void main(String[] args) {
		Abs.print();
		Abs1 a = new Abs1();
		a.display();
		a.test();
		a.test2();
	}

	private void test() {
	System.out.println("a method with static modifier");
	}

}
