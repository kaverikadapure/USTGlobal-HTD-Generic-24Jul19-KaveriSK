package com.dev.abstraction;

public abstract class Abstract1a extends Abstarct1{

	@Override
	void example() {
		
	}
	
	@Override
	void print1() {
		
		
	}
	
	abstract void print2();

	public static void main(String[] args) {
		
		

	}


}
