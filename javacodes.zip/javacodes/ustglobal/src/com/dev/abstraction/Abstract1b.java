package com.dev.abstraction;

public class Abstract1b extends Abstarct1{
	
	@Override
	void print1() {
		System.out.println("this is print1 method in concrete class");
	}

	public static void main(String[] args) {
	Abstract1b a = new Abstract1b();
	a.print1();
	a.example();
	}

	@Override
	void example() {
		System.out.println("this is example method in concrete class");
		
	}


}
