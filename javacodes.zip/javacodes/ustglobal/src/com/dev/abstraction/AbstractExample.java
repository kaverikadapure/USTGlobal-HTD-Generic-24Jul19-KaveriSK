package com.dev.abstraction;

public abstract class AbstractExample {
	
	public AbstractExample () {
		System.out.println("constructor of AbstractExample class");
	}
	
	abstract void display();
	abstract void print();
	
	public void show() {
		System.out.println("concrete method of abstract class");
	}
}
