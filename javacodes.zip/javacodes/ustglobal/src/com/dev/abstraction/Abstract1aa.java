package com.dev.abstraction;

public class Abstract1aa extends Abstract1a implements Abs,Abs2{

	@Override
	void print2() {
		System.out.println("This is print2 method in sub child class");
		
	}


	public static void main(String[] args) {
		 Abstract1aa a = new  Abstract1aa();
		 a.print2();

	}


	@Override
	public void display() {
		  
		
	}

}
