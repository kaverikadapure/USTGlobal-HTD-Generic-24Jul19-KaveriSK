package com.dev.abstraction;

public interface Abs {
	
	void display();
	
	
	public static void print() {
		
	}
	 
	static void test() {
		
	}
	
	default void test2( ) {
		System.out.println("test2 method");
	}
	

}
