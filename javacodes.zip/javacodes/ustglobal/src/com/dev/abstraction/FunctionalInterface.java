package com.dev.abstraction;

public abstract class FunctionalInterface {
	
	abstract void show();
}
