package com.dev.abstraction;

public interface Abs2 extends Abs{
	
	void display();
	
	public int i = 7;
	
	public static void print() {
		System.out.println("A");
	}
}
