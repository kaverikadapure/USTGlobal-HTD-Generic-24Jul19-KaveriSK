package com.dev.abstraction;

public abstract class Abstarct1 {
	
	abstract void print1();
	abstract void example();
	
	public void print() {
		System.out.println("concrete method");
	}

}
