package com.dev.inheritance;

public class GrandFather {
	static GrandFather g = new GrandFather();
	
	String lastName = "Stark";
	String name = "Torrhen";

	
	public void printName( ) {
		//String name = "Torrhen";
		System.out.println(name+" "+g.lastName);
	}
	
	public static void main(String[] args) {
		g.printName();
		
	}
}
