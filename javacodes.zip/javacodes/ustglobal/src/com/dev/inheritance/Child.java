package com.dev.inheritance;

public class Child extends Parent {
	static Child c = new Child();
	
	String tname = "flies";

	public void printName( ) {
		
		System.out.println(super.fname+" "+sname+" "+" "+tname);
	}
	public static void main(String[] args) {
		c.printName();
	}

}
