package com.dev.inheritance;

public class Parent extends GrandParent{
 static Parent p = new Parent();
 String sname = "fly";
 
 public void printName( ) 
 	{
		System.out.println(super.fname+" "+sname+" ");
	}
	public static void main(String[] args) {
		
		p.printName();
	}

}
