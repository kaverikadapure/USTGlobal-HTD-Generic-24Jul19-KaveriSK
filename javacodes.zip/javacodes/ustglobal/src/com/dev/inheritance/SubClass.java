package com.dev.inheritance;

public class SubClass extends SuperClass{

//	public SubClass() {
//		System.out.println("const with no args of SubClass");
//	}
//	
//	public SubClass(int j) {
//		System.out.println("const with int args of SubClass");
//	}
//	
	public SubClass(String p) {
		System.out.println("const with String args of SubClass");
}
	
	public SubClass() {
	
	}
	
	public static void main(String[] args) {	
	SubClass s = new SubClass();
	}

}
