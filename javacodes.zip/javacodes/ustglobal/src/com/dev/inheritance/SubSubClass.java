package com.dev.inheritance;

public class SubSubClass extends SubClass {
	public SubSubClass() {
		super("y");
	}


	public static void main(String[] args) {
		
		SubSubClass p = new SubSubClass();
	}


}