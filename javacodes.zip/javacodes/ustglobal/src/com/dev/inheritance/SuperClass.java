package com.dev.inheritance;

public class SuperClass {
	
	public SuperClass()  {
		System.out.println("const with no args of SuperClass");
	}

	public SuperClass(int i)  {
		System.out.println("const with int args of SuperClass");
	}

	public SuperClass(String s)  {
		System.out.println("const with string args of SuperClass");
	}
	
	public SuperClass(String s, int i)  {
		System.out.println("const with string and int args of SuperClass");
	}
	
	public SuperClass(int i, String s)  {
		System.out.println("const with int and string args of SuperClass");
	}

	public static void main(String[] args) {
		
	}

}
