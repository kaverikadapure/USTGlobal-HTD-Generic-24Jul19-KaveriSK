package com.dev.inheritance;

public class GrandParent {
 static GrandParent g = new GrandParent();
 String fname = "butter";
 
	 public void printName( ) 
 	{
		System.out.println(fname+" ");
	}
	public static void main(String[] args) {
		
    g.printName();
	}

}
