package com.dev.contsructors;
import com.dev.methods.MethodExample;
public class Demo {
	public static void main(String[] args) {
		int i = MethodExample.areaSquare(3);
		System.out.println(i);
		System.out.println(MethodExample.j);
	}
}
