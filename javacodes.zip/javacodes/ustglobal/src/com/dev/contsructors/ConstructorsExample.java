package com.dev.contsructors;

public class ConstructorsExample {
	public ConstructorsExample() {
		System.out.println("this  is no-arg const");
	}
	
	public ConstructorsExample(int i) {
		System.out.println("This const is with i  arg");
	}
	
	public ConstructorsExample (String s) {
		System.out.println("this  const is with String arg");
	}
	
	public ConstructorsExample (String s,int i) {
		System.out.println("this  const is with String and int arg");
	}
	
	public ConstructorsExample (int i, String s) {
		System.out.println("this  const is with  int and String arg");
	}
	
	public static void main (String[] args) {
		ConstructorsExample ce = new ConstructorsExample();
		ConstructorsExample ce1 = new ConstructorsExample(1);
		ConstructorsExample ce2 = new ConstructorsExample("A");
		ConstructorsExample ce3 = new ConstructorsExample("A",1);
		ConstructorsExample ce4 = new ConstructorsExample(3,"A");
	}
}
