package com.dev.contsructors;

public class Overrulling {
	
	public Overrulling () {
		System.out.println("no arg constructotr");
	}
	
	public Overrulling (int i,int j) {
		int sum=i+j;
		System.out.println("sum of two numbers: "+sum);
	}
	
	public Overrulling (String s) {
		System.out.println(s);
	}

	public static void main(String[] args) {
		Overrulling c = new Overrulling();
		Overrulling c0 = new Overrulling(2,3);
		Overrulling c1 = new Overrulling("butter");
		
	}

}
