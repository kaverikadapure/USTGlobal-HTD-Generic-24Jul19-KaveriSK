package com.dev.methods;

public class Demo {
	final static int INT = 2;
	
	final static void print() {
		System.out.println("final method");
	}
}
