package com.dev.methods;

public class Code {
	static Code c = new Code();
	
	public void add(int a,int b,int c, int d) {
		int sum = a+b+c+d;
		System.out.println("sum of 4 numbers = "+sum);
	}
	
	public void add(int a,int b,int c) {
		int sum = a+b+c;
		System.out.println("sum of 3 numbers = "+sum);
	}
	
	public void add(int a,int b) {
		int sum = a+b;
		System.out.println("sum of 2 numbers = "+sum);
	}

	public void mul(double a,double b) {
		double product = a*b;
		System.out.println("product of 2 numbers = "+product);
	}
	
	public void mul(double a,double b,double c) {
		double product = a*b*c;
		System.out.println("product of 3 numbers = "+product);
	}
	
	public void mul(double a,double b,double c, double d) {
		double product = a*b*c*d;
		System.out.println("product of 4 numbers = "+product);
	}
	
	public void subs(char a,char b) {
		int res = a-b;
		System.out.println("substracting two characters =  "+res);
	}
	
	public void subs(int a,int b, int c) {
		int res = (b-a)-c;
		System.out.println("subtraction of 3 numbers =  "+res);
	}
	
	public void subs(long a, long  b, long c, long d) {
		long res = (a-b)-(c-d);
		System.out.println("subtraction of 4 numbers =  "+res);
	}

	
	public void div(float p, float q) {
		double quo = p/q;
		System.out.println("quotient = "+quo);
	}
	
	public static void main(String[] args) {
		c.add(3,5);
		c.add(3,5,4);
		c.add(3,5,4,2);
		
		c.mul(2.5, 1.3);
		c.mul(5.0,8.2,6.9);
		c.mul(1.1,2.2,3.3,4.4);
		
		c.subs('J','a');
		c.subs(5,10,1);
		c.subs(2, 1, 6, 4);
		
		c.div(10,5);
	}

}
