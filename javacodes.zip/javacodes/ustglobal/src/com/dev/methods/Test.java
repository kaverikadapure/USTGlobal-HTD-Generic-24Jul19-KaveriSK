package com.dev.methods;

public class Test {
	
	public static void main(String[] args) {
		Demo.print();
	}

}
