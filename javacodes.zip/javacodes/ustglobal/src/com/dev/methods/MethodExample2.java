package com.dev.methods;

public class MethodExample2 {
	       
	public static void main(String[] args) {

		MethodExample2 me = new MethodExample2();

		int c = me.areaRec(2,4);
		System.out.println("Area of rec is: "+c);
		
	}
	public  int areaRec(int len, int width) {
		
		int area = len*width;
		return area;
	}

}
