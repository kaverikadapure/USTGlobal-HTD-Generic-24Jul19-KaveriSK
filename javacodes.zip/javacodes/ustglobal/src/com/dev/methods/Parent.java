package com.dev.methods;

public class Parent {
	static Parent p = new Parent();
	
	public void print() {
		System.out.println("in parent class");
	}

	
	public static void main(String[] args) {
		p.print();
	}
}
