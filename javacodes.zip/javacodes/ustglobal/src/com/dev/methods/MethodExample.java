package com.dev.methods;

public class MethodExample {
	public static int j = 0 ;

	static MethodExample me = new MethodExample();

	public static void main(String[] args) {
		
		//MethodExample me = new MethodExample();
		
		j = areaSquare(6);
		System.out.println("Area of square is: "+j);
		
		int c = me.areaRec(2,4);
		System.out.println("Area of rec is: "+c);
	}
	public static int areaSquare(int side) {

		int t =side*side;
		int n = me.areaRec(4,8);
		return t;
	}
	public  int areaRec(int len, int width) {
		j = len*width;
		return j;
	}
}
