package com.dev.methods;

public class Child extends Parent {
	static Child c = new Child();
	
	@Override
	public void print() {
		System.out.println("child class");
		
	}
	public static void main(String[] args) {
		c.print();
	}

}
