package com.dev.lambda;

@FunctionalInterface
public interface FuncIt {
	public void printIt(int i);
}
