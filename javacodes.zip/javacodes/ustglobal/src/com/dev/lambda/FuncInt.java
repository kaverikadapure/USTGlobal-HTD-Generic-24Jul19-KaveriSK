package com.dev.lambda;

@FunctionalInterface
public interface FuncInt {
	public void printVal();
}
