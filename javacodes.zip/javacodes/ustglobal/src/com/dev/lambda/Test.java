package com.dev.lambda;

public class Test {

	public static void main(String[] args) {
		
		FuncInt f0 = () -> System.out.println("Functional Interface");
		f0.printVal();
		
		FuncInt f = () -> {
			for(int i=1; i<=10; i++) {
				System.out.println("i = "+i);
			}
		};
		f.printVal();
		
		FuncInt f1 = () -> {
			try {
				int i =10/5;
			System.out.println("quotient = "+i);
			}catch(Exception e){
				System.out.println("Execption");
			}
		};
		f1.printVal();
		
		FuncIt f3 = (int i) ->  {
			for(int j=1; j<=i; j++) {
				System.out.println("j = "+j);
			}
	};
	f3.printIt(5);
	}
}
