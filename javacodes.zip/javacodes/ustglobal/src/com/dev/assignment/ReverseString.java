package com.dev.assignment;

public class ReverseString {

	public static void main(String[] args) {
	
		String str1="Khush" ,str2="";
		int l = str1.length();
		System.out.println("Original String = "+str1);
   
		for(int i=l-1; i>=0; i--) {
			str2 = str2 + str1.charAt(i) ;	  
		}
		System.out.println("Reverse String = "+str2);
	}

}
