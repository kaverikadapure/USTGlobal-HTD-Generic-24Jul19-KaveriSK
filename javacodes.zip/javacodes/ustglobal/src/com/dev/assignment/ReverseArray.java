package com.dev.assignment;

public class ReverseArray {

	public static void main(String[] args) {
		int [] a = {10, 20, 30, 40, 50};
		int l= a.length;
		int [] b = new int [l];
		
		for(int k =0; k<l; k++) {
		System.out.println("original array: "+a[k]);
		}
		
		System.out.println();
		
		for(int i=l-1; i>=0; i--) {
			b[l-1] = a[i];
			l=l-1;

			System.out.println("reversed array: "+b[i]);
		}
		
	}

}
