package com.dev.assignment;

public class SumOfArray {

	public static void main(String[] args) {
	
	int [] a = {1,2,3,4,5,6,7};
	int l = a.length;
	
	System.out.println("first element: "+a[0]);
	
	int m = l/2;
	System.out.println("m= "+a[m]);
	
	int slast = l-2;
	System.out.println("second last element: "+a[slast]);
	
	int sum= a[0] + a[m] + a[slast];
	System.out.println("sum: "+sum);

	}

}
