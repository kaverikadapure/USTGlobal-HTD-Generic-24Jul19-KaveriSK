package com.dev.polymorphism;

public class Child extends Parent {
		static Child c = new Child();
		String str1 = "morning";

		public void printChar()
		{
			System.out.println(" "+super.str+" "+str1);
		}
		
		public int addSome(int i)
		{
			int j = 0;
			j=j+1;
			System.out.println("incremented value is: "+j); 
			return 1;
		}
		
		public int addSome(int i,int j)
		{
			int k = 0;
			k=i+j;
			System.out.println("sum is: "+k);
			return 1;
		}

	public static void main(String[] args) {
		c.printChar();
		c.addSome(7);
		c.addSome(2,3);
	}

}
