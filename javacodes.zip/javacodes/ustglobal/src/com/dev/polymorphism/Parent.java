package com.dev.polymorphism;

public class Parent {
	static Parent p = new Parent();
	String str = "good"; 
	
	public void printChar() {
		System.out.println(" "+str);
	}
	
	public static void main(String[] args) {
	p.printChar();

	}

}
