package com.dev.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CharactersMatching {

	public static void main(String[] args) {
		Pattern pat = Pattern.compile("\\w+\\@\\w+\\.\\w+"); //for email id's
		Matcher mat = pat.matcher("vinu@gmail.com");
		System.out.println(mat.matches());

		pat = Pattern.compile("\\w+\\s\\w+\\s\\w+"); //for first,middle,last name
		mat = pat.matcher("A B C");
		System.out.println(mat.matches());
		
		pat = Pattern.compile("[A-Za-z]{1,25}\\s[A-Za-z]{1,25}"); //for first name with limited char
		mat = pat.matcher("Vinay Kadapure");
		System.out.println(mat.matches());
		
		pat = Pattern.compile("\\w+\\W+\\w+"); //for alphanumeric password
		mat = pat.matcher("acf#3d");
		System.out.println(mat.matches());
	}

}
