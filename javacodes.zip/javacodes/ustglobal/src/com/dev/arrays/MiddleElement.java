package com.dev.arrays;

public class MiddleElement {

	public static void main(String[] args) {
	
		int arr[] = {11,22,33,44,55};
	
		int i =arr.length ;
		System.out.println(+i);
	
		if(i<=arr.length) {
		System.out.println("index is present");
		 i=i/2;
		 System.out.println(+i);
		System.out.println(arr[i]);
		
	}else
	{
		System.out.println("index not present");
	}

	}

}
