package com.dev.arrays;

public class ArraysExample {

	public static void main(String[] args) {
		int[] intArr = new int[5];
		int num[];
		char [] ch;
		byte[] no;
		
		
		num = new int[5];
		ch = new char[5];
		no = new byte[5];
		
		num[0] = 1;
		num[1] = 2;
		num[2] = 3;
		num[3] = 4;
		num[4] = 5;
		
		ch[0] = 'a';
		ch[1] = 'b';
		ch[2] = 'c';
		ch[3] = 'd';
		ch[4] = 'e';
		
		no[0] = 11;
		no[1] = 12;
		no[2] = 13;
		no[3] = 14;
		no[4] = 15;
		
		int res = num[1] * 3;
		System.out.println(res);
		
		res = num[2] % 3;
		System.out.println(res);
		
		res = num[0] + 3;
		System.out.println(res);
		
		res = num[3] - 1;
		System.out.println(res);
		
		res = num[4] / 5;
		System.out.println(res);
		
		res = ch[0] + 1;
		System.out.println(res);
		
		res = ch[1] - 1;
		System.out.println(res);
		
		res = ch[2] * 1;
		System.out.println(res);
		
		res = ch[3] / 2;
		System.out.println(res);
		
		res = ch[4] % 2;
		System.out.println(res);
		
		res = no[0] + 1;
		System.out.println(res);
		
		res = no[1] - 1;
		System.out.println(res);
		
		res = no[2] * 1;
		System.out.println(res);
		
		res = no[3] / 2;
		System.out.println(res);
		
		res = no[4] % 2;
		System.out.println(res);
	}

}
