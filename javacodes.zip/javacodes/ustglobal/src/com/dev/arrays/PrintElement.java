package com.dev.arrays;

public class PrintElement {

	public static void main(String[] args) {
		int [] intArr = {11,22,33,44,55};
		int i=5;
		
		if(i<intArr.length) {
			System.out.println("index is present");
			for(int j=0; j<=i; j++) {
				System.out.println(intArr[j]);
			}
		}else
		{
			System.out.println("index not present");
		}

	}

}
