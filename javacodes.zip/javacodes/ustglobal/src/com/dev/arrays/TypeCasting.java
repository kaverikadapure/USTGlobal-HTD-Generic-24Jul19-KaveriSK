package com.dev.arrays;

import java.util.Scanner;

public class TypeCasting {

	public static void main(String[] args) {
		//int i =10;
		//byte b = (byte)i;
		//int r = b;
		
		Scanner sc = new Scanner(System.in);
		int i;
		System.out.println("enter value");
		i=sc.nextInt();
		System.out.println(i);

	}

}
