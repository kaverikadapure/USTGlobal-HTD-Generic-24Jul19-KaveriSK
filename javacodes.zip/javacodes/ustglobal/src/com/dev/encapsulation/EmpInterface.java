package com.dev.encapsulation;

import java.util.HashSet;

public class EmpInterface implements EmployeeDetails{

	HashSet<Employee> hs = new HashSet<Employee>();

	@Override
	public boolean addEmployee(Employee e) {
		if(e!=null) {
			hs.add(e);
			return true;
		}
		return false;
	}

	@Override
	public void getEmployee() {
		System.out.println(hs);
	}

	@Override
	public boolean removeEmployee(Employee e) {
		boolean b = hs.remove(e);
		if(b) {
			return true;
		}
		return false;
	}

	

}
