package com.dev.encapsulation;

public interface EmployeeDetails {
	
	public boolean addEmployee(Employee e);
	public void getEmployee();
	public boolean removeEmployee(Employee e);

}
