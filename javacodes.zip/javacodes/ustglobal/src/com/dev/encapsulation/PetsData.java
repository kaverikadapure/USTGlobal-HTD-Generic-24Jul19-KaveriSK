package com.dev.encapsulation;

public class PetsData {

	public static void main(String[] args) {
		Pets dog1 = new Pets();
		Pets dog2 = new Pets();
		Pets dog3 = new Pets();
		
		Pets cat1 = new Pets();
		Pets cat2 = new Pets();
		Pets cat3 = new Pets();
		
		
		dog1.setAge(1);
		dog1.setName("Chotu");
		dog1.setColor("White");
		
		dog2.setAge(3);
		dog2.setName("Jack");
		dog2.setColor("Brown");
		
		dog3.setAge(2);
		dog3.setName("Max");
		dog3.setColor("Black");

		Pets [] dog = {dog1, dog2, dog3};
		
		System.out.println("Dogs");
		System.out.println("*********************************");
		
		for(int i=0; i<dog.length; i++) {
		System.out.println("dog age: "+dog[i].getAge());
		System.out.println("dog name: "+dog[i].getName());
		System.out.println("dog color: "+dog[i].getColor());
		System.out.println();
		}
		
		System.out.println("*********************************");
		System.out.println();
		
		cat1.setAge(1);
		cat1.setName("Minchi");
		cat1.setColor("White");
		
		cat2.setAge(1);
		cat2.setName("Sanchu");
		cat2.setColor("White and Brown");
		
		cat3.setAge(1);
		cat3.setName("Sona");
		cat3.setColor("Black and Brown");
		
		Pets [] cat = {cat1, cat2, cat3};
		
		System.out.println("Cats");
		System.out.println("*********************************");
		
		for(int i=0; i<dog.length; i++) {
			System.out.println("cat age: "+cat[i].getAge());
			System.out.println("cat name: "+cat[i].getName());
			System.out.println("cat color: "+cat[i].getColor());
			System.out.println();
			}
			
			System.out.println("*********************************");
		
		
	}
		

}
