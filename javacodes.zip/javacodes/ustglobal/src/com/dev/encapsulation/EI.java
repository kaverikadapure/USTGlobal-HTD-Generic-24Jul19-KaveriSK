package com.dev.encapsulation;

public interface EI {
	public Employee addEmployee(String k, Employee e);
}
