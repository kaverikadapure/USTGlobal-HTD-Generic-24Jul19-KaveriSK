package com.dev.encapsulation;

public class EmpData {

	public static void main(String[] args) {
		
		EmpInterface epd = new EmpInterface();
		Employee e = new Employee();
		e.setName("rithik");
		e.setId(12);
		e.setEmail("rithik@gmail.com");
		
		Employee e1 = new Employee();
		e1.setName("raunak");
		e1.setId(22);
		e1.setEmail("raunak@gmail.com");
		
		boolean b = epd.addEmployee(e);
		boolean b1 = epd.addEmployee(e1);
		System.out.println(b);
		System.out.println(b1);
		
		epd.getEmployee();
		boolean f =epd.removeEmployee(e);
		System.out.println(f);
		epd.getEmployee();
	}

}
