package com.dev.collections;

import java.util.HashMap;

import com.dev.encapsulation.Pets;

public class C3 {

	public static void main(String[] args) {
		HashMap<String, Pets> hm = new HashMap<String, Pets>();
		
		Pets p = new Pets();
		p.setAge(1);
		p.setName("shiro");
		p.setColor("white");
		
		Pets p1 = new Pets();
		p1.setAge(1);
		p1.setName("dolar");
		p1.setColor("brown");

		hm.put("1", p);
		hm.put("2", p1);
		System.out.println(hm);
		
		Pets d = hm.remove("2");
		System.out.println(d);
		System.out.println(hm);
		
		System.out.println("output of containsKey:" +hm.containsKey("1"));
		
		System.out.println("output of containsValue:"+hm.containsValue(p1));

	}

}
