package com.dev.collections;

import java.util.TreeSet;

import com.dev.encapsulation.Pets;

public class C4 {

	public static void main(String[] args) {
		TreeSet<Pets> ts = new TreeSet<Pets>();
		
		Pets p = new Pets();
		p.setAge(4);
		p.setName("shiro");
		p.setColor("white");
		
		Pets p1 = new Pets();
		p1.setAge(1);
		p1.setName("dolar");
		p1.setColor("brown");
		
		Pets p2 = new Pets();
		p2.setAge(3);
		p2.setName("roy");
		p2.setColor("black");
		
		Pets p3 = new Pets();
		p3.setAge(2);
		p3.setName("jack");
		p3.setColor("white-brown");
		
		ts.add(p1);
		ts.add(p);
		ts.add(p3);
		ts.add(p2);
		
		System.out.println(ts);
	}

}
