package com.dev.collections;

import java.util.HashSet;

import com.dev.encapsulation.Employee;

public class C2 {
	
	public static void main(String[] args) {
	HashSet<Employee> hs = new HashSet<Employee>();
	
	Employee e = new Employee();
	e.setName("Vinay");
	e.setId(1);
	e.setEmail("vinay@gmail.com");
	e.setPassword("1234vi");
	
	Employee e1 = new Employee();
	e1.setName("Pratiksha");
	e1.setId(2);
	e1.setEmail("pratiksha@gmail.com");
	e1.setPassword("2345pr");
	
	Employee e2 = new Employee();
	e2.setName("Ganesh");
	e2.setId(4);
	e2.setEmail("ganeshy@gmail.com");
	e2.setPassword("5432ga");
	
	Employee e3 = new Employee();
	e3.setName("sri");
	e3.setId(3);
	e3.setEmail("sri@gmail.com");
	e3.setPassword("3456sr");
	
	boolean b = hs.add(e);
	boolean b1 = hs.add(e1);
	boolean b2 = hs.add(e2);
	boolean b3 = hs.add(e3);
	System.out.println("output of add:" +b);
	System.out.println("output of add:" +b1);
	System.out.println("output of add:" +b2);
	System.out.println("output of add:" +b3);
	System.out.println();
	System.out.println("e: "+e);
	System.out.println("e1: "+e1);
	System.out.println("e2: "+e2);
	System.out.println("e3: "+e3);
	
	System.out.println();
	
	System.out.println("size of HashSet: "+hs.size());
	
	boolean b4 = hs.remove(e2);
	System.out.println("output of remove:" +b4);
	System.out.println(hs);
	System.out.println("size of HashSet: "+hs.size());
	
	System.out.println("output of contains:" +hs.contains(e3));
	
	e.setEmail("vinu@gmail.com");
	System.out.println("employee details after update: "+e);
	
	for (Employee employee : hs) {
		System.out.println(employee);
	}
	
	hs.clear();
	System.out.println("size of HashSet: "+hs.size());
	
	}
}
