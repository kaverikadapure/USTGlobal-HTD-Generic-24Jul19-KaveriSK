package com.dev.collections;

import java.util.TreeSet;
import com.dev.encapsulation.Employee;;

public class C5 {

	public static void main(String[] args) {
		TreeSet<Employee> ts = new TreeSet<Employee>();
		
		
		Employee e = new Employee();
		e.setName("Kaveri");
		e.setId(1);
		e.setEmail("kaveri@gmail.com");
		e.setPassword("123ka");
		
		Employee e5 = new Employee();
		e5.setName("Vinay");
		e5.setId(5);
		e5.setEmail("vinay@gmail.com");
		e5.setPassword("1234vi");
		
		Employee e1 = new Employee();
		e1.setName("Pratiksha");
		e1.setId(2);
		e1.setEmail("pratiksha@gmail.com");
		e1.setPassword("2345pr");
		
		Employee e2 = new Employee();
		e2.setName("Ganesh");
		e2.setId(4);
		e2.setEmail("ganeshy@gmail.com");
		e2.setPassword("5432ga");
		
		Employee e3 = new Employee();
		e3.setName("sri");
		e3.setId(3);
		e3.setEmail("sri@gmail.com");
		e3.setPassword("3456sr");
		
		ts.add(e);
		ts.add(e1);
		ts.add(e2);
		ts.add(e3);
		ts.add(e5);
		
		System.out.println(ts);
	}

}
