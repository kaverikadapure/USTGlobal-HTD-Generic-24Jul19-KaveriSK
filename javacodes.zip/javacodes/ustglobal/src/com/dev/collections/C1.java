package com.dev.collections;

import java.util.HashSet;
import java.util.Iterator;

import com.dev.encapsulation.Pets;
public class C1 {

	public static void main(String[] args) {
		HashSet<Pets> hs = new HashSet<Pets>();
		
		Pets p = new Pets();
		p.setAge(1);
		p.setName("shiro");
		p.setColor("white");
		
		Pets p1 = new Pets();
		p1.setAge(1);
		p1.setName("dolar");
		p1.setColor("brown");
		
		boolean b= hs.add(p);
		boolean b1= hs.add(p1);
		System.out.println("output of add:" +b);
		System.out.println("output of add:" +b1);
		System.out.println(hs);
		
		
		System.out.println("size of HashSet: "+hs.size());
		
		boolean b2 = hs.remove(p);
		System.out.println("output of remove:" +b2);
		System.out.println(hs);
		
		System.out.println("output of contains:" +hs.contains(p));
		
		System.out.println("size of HashSet: "+hs.size());
		hs.clear();
		System.out.println("size of HashSet after clear: "+hs.size());
	}

}
