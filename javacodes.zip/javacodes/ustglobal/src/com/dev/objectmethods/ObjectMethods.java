package com.dev.objectmethods;

public class ObjectMethods extends Object{
	
	public static void main (String[] args) {
		
		Pets p1 = new Pets();
		
		System.out.println(p1.getClass());
	}
}
