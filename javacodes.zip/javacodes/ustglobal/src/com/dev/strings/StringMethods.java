package com.dev.strings;

public class StringMethods {

	public static void main(String[] args) {
		String str = "Some_String";
		String str1 ="sOme_sTring";
		
		int length = str.length();
		System.out.println("length of string = "+length);
		
		char ch [] = str.toCharArray();
		System.out.println("char arr "+ch[4]);
		
		char c = str.charAt(5);
		System.out.println("char at index 5 = "+c);
		
		boolean s = str.equals(str1);
		System.out.println("compares two str = "+s);
		
		boolean sh = str.equalsIgnoreCase(str1);
		System.out.println("compares two str ignoring case = "+sh);
		
		boolean t = str.contains("_");
		System.out.println("contains _ "+t);
		
		String st = str.replace('S', 'A');
		System.out.println("replaced = "+st);
		
		int i = str.indexOf('k');
		System.out.println("index of i = "+i);
		
		String p = str.toUpperCase();
		System.out.println("upercase = "+p);
		
		String k = str.substring(3);
		System.out.println("output of substring(): "+k);
		
		String ka = str.substring(3, 6);
		System.out.println("output of substring(,): "+ka);

	}

}
