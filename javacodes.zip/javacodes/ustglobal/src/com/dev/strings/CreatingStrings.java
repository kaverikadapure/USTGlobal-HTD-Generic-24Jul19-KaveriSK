package com.dev.strings;

public class CreatingStrings {

	public static void main(String[] args) {
		
		String str;
		str = "Hello";
		
		String str1 = "Java";
		
		String str2 = new String("Hello Java");
		
		System.out.println(str);
		System.out.println(str1);
		System.out.println(str2);
	}

}
