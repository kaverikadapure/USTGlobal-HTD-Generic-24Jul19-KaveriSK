package com.dev.strings;

public class StringsExample {

	public static void main(String[] args) {
		String str = "Butterfly";
		String str1 ="buttErfly";
		
		int length = str.length();
		System.out.println("length of string = "+length);
		
		char ch [] = str.toCharArray();
		System.out.println("char arr "+ch[4]);
		
		char c = str1.charAt(4);
		System.out.println("char at index 5 = "+c);
		
		boolean s = str.equals(str1);
		System.out.println("compares two str = "+s);
		
		boolean sh = str.equalsIgnoreCase(str1);
		System.out.println("compares two str ignoring case = "+sh);

	}

}
