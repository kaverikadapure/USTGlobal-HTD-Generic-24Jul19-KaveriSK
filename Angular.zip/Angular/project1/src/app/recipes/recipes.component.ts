import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.component.html',
  styleUrls: ['./recipes.component.css']
})
export class RecipesComponent implements OnInit {

  rpData: any='';

  recipes = [
    {
      name: 'IDLI-DOSA-VADA',
      img: 'https://image.shutterstock.com/image-photo/group-south-indian-food-like-260nw-1153818823.jpg',
      description: 'Idli are a type of savoury rice cake, originating from the Indian subcontinent, popular as breakfast foods in southern India and among Indian-origin Tamils in Sri Lanka. The cakes are made by steaming a batter consisting of fermented black lentils (de-husked) and rice. The fermentation process breaks down the starches so that they are more readily metabolized by the body.A dosa is a cooked flat thin layered rice batter, originating from the Indian subcontinent, made from a fermented batter. It is somewhat similar to a crepe in appearance. Its main ingredients are rice and black gram ground together in a fine, smooth batter with a dash of salt. Dosas are a typical part of the Southern Indian and Sri Lankan Tamil diets, but the dish is now popular all over the Indian subcontinent. Traditionally, dosas are served hot along with sambar, a stuffing of potatoes, and chutney. They can be consumed with idli podi as well.Vada is a crispy deep fried savory food made of lentils. Usually they are made by soaking and grinding urad dal (skinned black gram) or chana dal (bengal gram) to batter. Then small portions of this batter is deep fried. Those made using urad dal are called medu vada' 
    },
    {
      name: 'VADA_PAV',
      img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSfbhsq-Qy6BKHq5kJsvEA4ClysWTuTVq19l73Q-0t0vyA0nfao',
      description:'Vada pav, alternatively spelt vada pao, wada pav, or wada pao, is a vegetarian fast food dish native to the state of Maharashtra. The dish consists of a deep fried potato dumpling placed inside a bread bun (pav) sliced almost in half through the middle. It is generally accompanied with one or more chutneys and a green chilli pepper.Although it originated as cheap street food in Mumbai, it is now served in food stalls and restaurants across India. It is also called Bombay burger in keeping with its origins and its resemblance in physical form to a burger'
    },
    {
      name: 'GULAB JAMUN',
      img: 'https://media-public.canva.com/MADas4q65wo/1/thumbnail_large.jpg',
      description: 'Gulab jamun is a milk-solid-based sweet from the Indian subcontinent, popular in India, Nepal, Pakistan, the Maldive, and Bangladesh, as well as Myanmar. It is also common in Mauritius, Fiji, southern and eastern Africa, Malay Peninsula, and the Caribbean countries of Trinidad and Tobago, Guyana, Suriname and Jamaica. It is made mainly from milk solids, traditionally from Khoya, which is milk reduced to the consistency of a soft dough. Modern recipes call for dried/powdered milk instead of Khoya. It is often garnished with dried nuts such as almonds to enhance flavour'   
    },
    {
      name: 'SAMOSAS',
      img: 'https://www.blueosa.com/wp-content/uploads/2014/11/2223030510_f0b5139bc2_z.jpg',
      description: 'Samosas are a fried or baked pastry with savoury filling, such as spiced potatoes, onions, peas, lentils and sometimes ground lamb, ground beef or ground chicken. They were introduced to India during the Muslim Delhi Sultanate when cooks from the Middle East and Central Asia migrated to work in the kitchens of the Sultan and the nobility. Indian samosas are usually vegetarian, and often accompanied by a mint sauce or chutney. Samosas are a common street food and many tourists or Indians eat them as a midday snack.'
    },
    {
      name: 'TANDOORI CHICKEN',
      img: 'https://cdn.pixabay.com/photo/2014/07/11/20/08/chicken-390262__340.jpg',
      description: 'Tandoori chicken a popular North Indian dish consisting of roasted chicken prepared with yogurt and spices. The name comes from the type of cylindrical clay oven, a tandoor, in which the dish is traditionally prepared. The chicken is marinated in yogurt and seasoned with the spice mixture tandoori masala. Cayenne pepper, red chili powder or Kashmiri red chili powder is used to give it a fiery red hue. This dish goes so well with steaming basmati rice and crispy naan.'
    },
    {
      name: 'DHOKLA',
      img: 'https://image.shutterstock.com/image-photo/chana-dal-dhokla-served-mint-260nw-1070642987.jpg',
      description: 'Dhokla is a vegetarian food item that originates from the Indian state of Gujarat.It is made with a fermented batter derived from rice and split chickpeas.Dhokla can be eaten for breakfast, as a main course, as a side dish, or as a snack. Dhokla is very similar to Khaman, however Dhokla is made of batter derived from rice gram and is white in color, whereas Khaman is typically made from Chickpeas gram and looks yellow in color. Khaman has become widly popular outside Gujarat but is misunderstood or incorrectly known as Dhokla'
    },
    {
      name: 'MASALA CHAI',
      img: 'https://cdn.pixabay.com/photo/2017/07/17/13/45/tea-2512434__340.jpg',
      description: 'There’s nothing like the experience of stopping a Chai Wallah on the street and ordering a steaming cup of masala chai when in India. Made by brewing black tea with a mixture of aromatic spices and herbs. The beverage has gained worldwide popularity, becoming a feature in many coffee and teahouses. Traditionally it is prepared by a decoction of green cardamom pods, cinnamon sticks, ground cloves, ground ginger, and black peppercorn together with black tea leaves, In international tea shops, it’s often sold in a tea bag form, with a variety of revolving recipes, but once combined with steaming hot milk, it’s delicious all around, whether found in India or your hometown.'
    },
    {
      name: 'MATAR PANEER',
      img: 'https://image.shutterstock.com/image-photo/cottage-cheese-peas-indian-gravy-260nw-310379780.jpg',
      description: 'Matar Paneer is a vegetarian north Indian dish consisting of peas and farmer’s cheese (paneer) in a tomato based sauce and spiced with garam masala. It is often served with rice, naan, paratha, poori, or roti (depending on the region). Most lovers of this dish recommend dipping whatever bread is accompanying the meal into the delicious tomato gravy.'
    },
    {
      name: 'NAAN',
      img: 'https://www.blueosa.com/wp-content/uploads/2014/11/319252332_16d4373176_z.jpg',
      description: 'Naan is a leavened, oven-baked flatbread that’s normally served with all meals. Typically, it will be served hot and brushed with ghee or butter. In non-traditional circles, different varieties of naan are available, like garlic naan or cheese naan. However you eat it, naan acts as almost a spoon to soup up sauce or dipped into chutneys. An Indian meal isn’t complete without naan at its side.'
    },
    {
      name: 'Punjabi-Style Chole Curry',
      img: 'https://cdn.pixabay.com/photo/2015/03/16/21/59/chana-676882__340.jpg',
      description: 'A classic and easy chole chickpea curry, is a favorite in Northern India and has become a worldwide sensation. Its perfect for a crowd, especially if you serve it hot along with fried Indian leavened bread like poori or bhatura.'
    }
    
  ]
  

  constructor() { }

  sendRp(recipe){
    this.rpData=recipe;
    console.log(recipe);
  }

  ngOnInit() {
  }

}
