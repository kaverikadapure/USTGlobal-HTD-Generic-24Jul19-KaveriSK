import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  nData: any='';

  news = [
    {
      title: 'Flood situation worsens in Belagavi',
      img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRiOYkskyd1O13n8mFSTMA1H7tkzbydJZZP_KsvKA4D_T_SciLZlw',
      details: 'The Hidkal dam has filled to the brim leading to the discharge of water downstream. The discharge of about 1 lakh cusecs from the dam added to the inflow at Almatti.Problems continued to compound in Belagavi and Chikkodi subdivisions wherein barring Ramdurg and Savadatti rest of the places were grappling with floods'
    },
    {
      title: 'Amul’s tribute to Sushma Swaraj ',
      img: 'https://www.hindustantimes.com/rf/image_size_300x200/HT/p2/2019/08/07/Pictures/_54df3694-b916-11e9-8601-ae4f2ce17a49.jpg ',
      details: 'Shared about an hour ago, the tweet has collected over 1000 ‘likes’ and more than 260 retweets'    
    },
    {
      title: 'Resign from Rajya Sabha,Mehbooba Mufti',
      img: 'https://www.hindustantimes.com/rf/image_size_300x200/HT/p2/2019/08/08/Pictures/hindustan-minister-president-mehbooba-addressing-democratic-conference_e3ff6074-b94d-11e9-a203-e6c4ad816de5.jpg',
      details: 'The Peoples Democratic Party, which was in an alliance with the BJP till the latter withdrew support in June 2018, has two members in the Upper House'    
    },
    {
      title: 'Virat Kohli',
      img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFHMSCXsAd-C2pafTVtvIQ62LflD7epUwhGMzSrHbnEnTutv9P',
      details: 'Virat Kohli is just 19 runs away from becoming the batsman with the most ODI?runs against West Indies. Kohli (1912 runs) is in the second position with Pakistan legend Javed Miandad leading the charts with 1930 runs'    
    },
    {
      title: 'Abhinandan Varthaman',
      img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNk7QpWQ3LdC1xXEB3ahea2fANnOCq2L0mqDm4zZ66k1yCiRGP6Q',
      details: 'Varthaman is likely to be awarded a Vir Chakra for his exploits and the five Mirage-2000 fighter aces who dropped bombs on the terror facility of the Jaish-e-Mohammed, the Vayu Sena Medal for gallantry'
    },
    {
      title: 'Sushma Swaraj:India will miss her',
      img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUQEhIVFRUVFRUWFRUVFhUVFxUVFRUWFhUVFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQFy0fHx0tLS0rLS0rLS0tKy0tKy0tLS0tLSstLSstLS0yLS0tNy0tLTAtLS0tLSstLS0xLS0tK//AABEIAKgBLAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQQFAgMGBwj/xAA/EAABAwIEAwYDBgUCBgMAAAABAAIRAyEEEjFBBVFhBiJxgZGhEzKxB0JSwdHwI2JygpIU4RUkosLi8VODsv/EABoBAAMBAQEBAAAAAAAAAAAAAAABAgQDBQb/xAApEQACAgEDAwMEAwEAAAAAAAAAAQIRAxIhMQRBURMiMgVxodGBkcFC/9oADAMBAAIRAxEAPwDyVNIITOoJhJNADQhNAAFkkgIGNNCEwGFExtT7qlqrrOkkpEyMQmFiE0EGTVJplRQsw5AiypuW9lTdV1CpdS2lMCyo1+fopY4qW6QP7Wunb7yy4NwGpWgxZdrw7sS2JcPVcZZIrY7wxyZxTy4u+I0bd4RFtJA9bjmpOL7OVXZnNaeYgajaPVehYbsqxvnt5QVe0cKGsDeVlweSnaNenVBRfY+e8RSLCWvbB6hRab4dde1dquzzKzD3RmvHNeL8SpOpvLHDQ/8Apd8eTWY8mNwZKCaj4SpIUhdQQk0IQAJJoQAikmkgASTKSABJNEJgYwmmlKBEROEISAaaSaAGgIQmMaaSaAGE0gmkBjUNieiqirWrofAqqhBEhgIQhBI0wktjGoEbMOwkrsezfAy6HuCruzHC/iumLBep8H4WGj8lny5OyNOHF3ZY8FwDWNAiFeMhRqDI8FtcYWWzYkbHFa8yr+McUZQpOrO0EWGpJIAA8yq7sx2kZi84yFjmQS0kGWm0gjrqOoRT5LS2LnFMELxr7S8F8Os1w0cCD4g2+q9ifUzLz77TMAXUDUi7HB3kSAfqrxOpHHNG4s8ywT7qxVXhvmVotyMUQQhCYwQhCYxIQkkIEk0QmAk0JFAAsU0kARkICEhGQQkEwgY00kwgAWSSaYDQgJpAYVj3T4KrVpXFj4Ku+GdYSJZgsgEQmCmQNZ0WFzgBunhsM6ocrRJXonZPsnkHxHiXRPh4LnOaii4Qci47E8JyUxmFzC7VjqdMS5wC5VuOfJp0IGxeRPjC2M4EH3q1nOcdt1je73Nq2VIv6/aGgzulwvpK0DjDHGA4cly+M4NRZbO1vQkD9lQ3UMkDUbEckmi4tnY8UwjcTSdScYzQQRsQZafUBVvBODtwec5sznAAmIhoMwB4/RbuC4mRB281X9rMYWgNBguMJJuqLsnYntBSpC7pPIfuyo+N8aFak+i5pioxzQdwXNIBHqPRVuFpUx80vd+FjS4jxACsnY+gyGua5s6CpTeyegJEFWtt6OUt9rPMsPhyD3hBGymBbsY2KtSNM748Mxj2haVtjxZjqgQhCoASTKSABJNCAEmEQhMDEpFMpIASEFCBEYJpISAayWITQMaaEIAaYQEwmA0IQgDViHQD4FdHTwOQCk1olrQXOIBkx3vc+y5yqZBHT6hdzhqjatMVx9+nTcej+8148nNKz5m1R0wJSbOD4vQDKhDdDeOU7LVgcI6q8MbqSrPjPffmiIt49VM7LtAqB37ur1VCzno99Ha9nezbaTRbvHUro8QIbl0BHhKw4bWEDyVxTykTAWByt7m7TS2OGxGObSlrLnoL+gVR/rsU4PcabiQJyuzBoHg09473t0Xp9bAsNw0TzgXVbisAGmSHMP4mgkecXCuLSJabR57gcVXruDXNo5Q0z3GRvu0Dci3TVMYeo3usblzT3ZluwMHYX0PkuyxOZwgVy7aGgSfHKJW/AcBcbvOUW7puSf5uXNVKSFGLQuyFKzc2tg4dQn9pPBKhFOrTBIBLXAayYy320InqF0/D+GNZBECOSt8fhBWoupkTI356g+oCmCHNngo4fiWgtFanSBGgc5pnkXFt/JbKfC3uc1rKrnMOXObuBIgzfeZXeV+BZpNJ5bcgtNwCDBHRY4Ls25rs9V5cBoBMKtYtB5p2kwpp1oP3mNdPM3b/ANnuqpd19ofD+62sB8ry0/0vmJ8HNA/uXDFasUriZ5qmJCELoQCEITASE0JDEkmkmIRSTKSBAUkIQBGTSTCAQLIJJpAMJpJpjBZBIJhADCaQSqugSkJkWo+5XV9gccwtqYaoYA77TyDoDvIHL/mVyLgt3C8e7D1mVm/dNx+Jps5p8QT7KZx1RoWOWmVna9oeAuYG6OaRYjeTv1UHs/hspIPn7LsjhjkIBOTRrTcAWMdLEKndhhTeW6zHsf8AZY1PajY4K7On4Y24H70XRYena65HhmIgrrMNiJauLR2W5KZSM2ClDDTqtFDEALacX1QqHTE6iGql4vjS2zBLjp+Sk47HwCVz1I1KhdW5Xa38QFyPEhNKw4Oq4c94Azgid9l0GGq2XGjtzhmjI+Rt8rjB5GBZSafaSm9ocxwIOhFwri9JEo6iVjy2nWzDSpc8g4a+oj3WfxguY41xprmlgmZaWkaZgd/7c3qssNxLu3KhlxRH+0FjThKv9h9KrCvJl6D20x04dzfxFo/6gfoCvPlr6f4mXP8AISEIlaDgCFP4NwbEYt5p4ak6o4AF0ZQGgmAXOcQBod5MGJhTn9jeIhzm/wCjrSz5oaHC+mVwMO/tJQBRJJkagggiQQbEEWIIOhSTASSZSQAJIQgBIQkgRHCaQTQAwmkEwgYwmkE0AMJhIJpANaMXNlIWvENlpQJ8EMlanNmy3MYVtbTQQemcO4wysGuaQ1rwX1GOgkVA2mHw7UAOYcs/df1KiYWsKrC4GclWq2egqFw9nBcbhaJNhIJ3Fl13ZrD5GFvMz5xCxSgot0bccm0ky5wdonRdFhXW8lT4RnPz8VaYWIjcLk0d4kqpWjdRqmOhbcs2K1VcECFNFlTi8Wajvhjz8Fd4Ch3APD6KkZRFJ5tNp5nx+iyqcXxBJbQoPIH3soEnpmIVxi3wS3ZM4pw5pBJaCecLmGYF7HkNsD6rbi+1uIpnLUo1GmYOei6Nbw5sg+S0jtd8R2SnhnF25DXAe4CvRIlNeTdiKeRobyM+aeFe4c+i00KlSq/+K3LJkDoLK1xDmsbfYKJLsXFnJdqsVLm0+XePnYfn6qgK342uaj3PO59tvZaFuxx0xSMGSWqTYwCbASTYAaknQDqV7l2d7MYTC4XI+jSq1Cz+K+oxry9x1AzAwwGQANusleT9i8F8XG0WnRpNQ/8A1guaf8sq9S4m+oKTgx5JiABrJ0HPVc8s2nR0xQTVs3dkqFDB03sZDc9Wo/8AtJPwxPIMDQPDqpdDiNSpWNKlc/NJMACdytLcCWgMAzQAA7wF7KH2RxID8RUNgauRhiZbTAnT+Zzh5Lhqb5NKpXRxnbDsDXw9OrjTWp1DndUq02hwLRUeSS1xs+C69m2lcKV7F24xmahiGg2+E/3BleOFa8crRkyw0gUkJLocgSTSQAJQhCBEdZLEJhIBppJhMBphIJoGMLJYrJIBhZAJBXvZzghrHO8dyf8AKPyUzmoq2dcOGWWWmJA4fwJ7x8SIZtrLtZjoI1WL+EvOeoBDGvc3n8jiD7heq8bwQbSw7qbYpmkGyIABLQ4Nv/KHbbFROCYIPpup5RGd7iZv/EPxLcxLyJ/lKzvM7O0umiscWvLs5PhPCg4A8xY8j1VvhKJY51N1jGYdRoY9kcPoOwuIdhaghrpdRdsQT8niNI/UK84jgs7A9nzMuOo3b6LlJ7jgtiNh3fopT5HebdVDMRN/XoRz6qTQxhChs7JFlT4jzWz/AIi2NVVVcS3Va2Ppud+XNSUy7wdGXmqR80AeAUnGPayMtjzC34d4NPKNIVS6g97iBNtSqT8EGVTjjQC2pDusQddxoq6pxphBbTYJO62O7OOdcrI8FbTvKvUytRGrUx8MPHzNvb3HouV7Q8ScRk0n6Lr+I1G06LjOjTP5LzXHYrO7MTGwkq8UNUr8HDJLSq8mlJCYGg1JIAAuSTYADc9FtMZ3P2W4Pv1sSRYAUWm/zOIe8eQFP/JdxjXZ6lKmNGvFR0E6MMt0t8+T3Vd2SwrqOGo08uR+SXtcHAtc+XvDgRYyTYqz+KHTdpOaBMCwESCRAuT6LFN3I1wVIkcUxeSjUe50BrXE3tABNz+Sj9nuHOp4WkCMrnN+I8GSW1KhNRwgci6PJRuKsNRooAWqPaHOsAaTXB9UwNiBkncuCtq9chuu3lCmiro5TiuFOIqVMO1wHxP4QOsWknrAv5Kg+0bsdQwFOjUoPqOzO+G8PLT3shcHiAI+U2uNNIvbdiK5r4l1U6NzPHjUMN88rSn9rOJBoU27/GafSnU/IrpjlTonLFSV+Dy5CCktRkBJNJMAKSEIERwmkEwgBphJZBAwTQhAGQTSC63sdwcOiu9oP4A7S33o3/8AIFc8k1BWzv0/Tyzz0o09nezDqsVKwLaezdHOtafwt912rKAaA1ogDl5Cw9b3PgpTW/v9+SZavPyZHN7n0vT9PjwxqP8AZc8HYMThqmFPz05fTmdCcw12DpaeTS3mqDAv+DVvYHuvBIkQdwNMpLvJzzsFuo13UnipTOV7TYx0u0j7zTuPoYKkcWxtLFHO4fCqxBmMji2bhxtyHei1rwE001Xcx5uncXJV7Zb34f6LHivB6eIYA5oJaQ5siYcPC8fu2q5HhvE30ahwuKGWo2wds8bEHeZF952MhdVwPiMfwKph7bA/jAt6jQg3t4rPtNwBmLpxYPF2P+rXDca84MG+hF4Z504uLOd4twnP/Fo2d95uz/0d1XOiuQTaCDBabEHwVpwniFSgTRrT3bEHVsWJ5uZp39L7i6m8X4Yyu3MDlfFnjXwPMIa8lRkU7MrhKjV6Rbp5dOngoGIrVKDstQR/MPlP6KQzjQi6VF2mdJwXjILQCdNQuip49gFhM/uF5fXxzJzNOU9FIw3aEjW46WRTBpM9GqcR6QqzE8SabHQxPguOxfaGRN/NVGK49UcIbYc10jCUuCJyjBbst+2nFWuijTNiQX9APlHrJ9FafZVXpD47XMY5xyyXNBJpwRlvtIcfPwXnxO5V/wBhnH/VBoMB7HB3gIP5e61OGmFGRTudstvtG7MNw7hisO0NovIDmN0pvOhA2Y7lsbbhVHYW2Oou/BncJ5im4A+RM+S9Q4ph21sPUw77h7cs8pEtd5GD5LyzsSx5xlOB8rXufvlaGwT17xa3xcEoz1QZUoKM0+zPVxWEZi4ECZh2+8iVUUuIik6o0vpuZVNE0QGFz2yQ+o4hrS8NyZw6REuA8bh2DDgRYaZucHbxuVr/AOGtz54Fxyn0/Rcouipx1GGBxfxKtUtc14a1jWlrg4l3ec4EuAy2yWIC1dpMf8HD1XHU0yBtBcIkwSN+mi3UWCnJhwNR5J7o2AY0OA0s0G25K5vtNNXEYXCaipVDngzBZT77gR1AcFPcaZe9hMCKeFzOaWuqEPGoIYGhrfKBP9y5T7SXAsbFwKov4sqf7Lt8bXNNpEggGGgDbaI0PNef9sqmbDh34qrT4d18eNk4/JBL4s4pJCFtMgkIQgBIQhIRHTSCyCYxppJoAYTSCtOB8JdiH3kMHzHn/KP12Uykoq2dMWOWSShHlhwPgz8S8AAhgPef/wBrebvovUMJhw1oa0QBoPRaeH4NrGhrWhrRAiOg09fqrFg5ei87Jkc2fS9N00enjS3b5Zg2mT+/0Wfw/wB2/XqtoHT2/UrNnSf+hQdXNkN9D92UWvQ1nQ/pGu41Vu4xqHeUH2WutUtJj+sD0zD9jwSHHK/BUMrNtTqSBMsqDWmQLSfw6DpppGWz4dxx1N3wa8Ts7Zw2PRVWKxjQYqMA2JbbzF9P0IQ6kwsDS6aZPcfrkO4I/DsRt6RSlapmfP00X7kv4/X6Oj4zwxlWK7WB9RgJa3MWipAkNdBGYTsbXIkTI4/DY7I2QCGSWuaZmk8GC2SBLeR2Pd2VtwrilTDu+HVuz1yjmD95nuJWfajhwIONogGWxWGz2Qe8YBJjkIuQTFyrW+zPKy4pYnfZlXjAyq2CAVyPEeFZDLdFeGR8sx11HQjY9FjVfmCW6YtmcnUkarKhJMK5xGBDhooowRaZ2VWLdMk4Xh1KuBSc7I4OnOACYLYykSLaFasf2Z+E4B1XKDYPcyWzyJB7p8QouDxP/MO8QI8GhdxTLarDSfcQNby13ynxsR4tlP1JQ2TPSw9NhywTlHc5A9kq8w19Ezpmc5s+HdIPkVY9neA4nD4lj3sGWHAua9pAkWkTOsbbqTwvFuw9T/S1TLD8jjyOnl9Cukc6AY5fS6fryezFk+m4lvGy4NA5TMHunXcgWXPdkuBtoGtVPzVargwfhotJIHQl5d5MauoDQ4bjNAkatHOTadduXlBrktqNgRBte0EQQT7p7pHl8vfsTW6OPXTwA/3W5piCNh5aKor1TmgGSHDNBBEEgajTTdSBiIqfDLm975QTBJGobzUD7El5t/VI8OZHNR6mBY2qKpgltMsBi4lwJdb9x5rJ+LaO6bbXEAC8T7+hWFDE52l14PyjfLoCR1VWKis4/i4aS3YWA5mw+q4/tsf+XpCNag9mPK7HijWwLR3m+149lz/b0A4QdKjCOhu23k4qsfKFP4s87QkmtpjBJCEgBCESgRoCaxCyTGMJhJbKFFz3BjGlzjoB+7DqlYJW6Ru4fg3VnimwXOvQbkr0RjaGCogVHBrWi06uJF4G5JJ0G3RcezibMFTLaWWpXfGZ+rWfyt/FEa6Ksw9Kriqmeo4uJ1J/dljytze+yR7fSVgVRVzf4OwrdsH1TkwlL++pp/iPzKzocMrVjmxFeo/+Vrixg8GtgJ8MwTWAADx6q5pvWVy8Hs48G15Hb/Bro8MpjRrvEVaoP+QdKsaGdu5I5PIf7uE+61setrXpJlygvBI+OQZyx/Tp5tWTaodpY7g6Gfoo+dYVCdgD7H1TOfpo0cSw4IiLXAn7p1yuOw6+HnUcJxHwqhoP+V+nRw0PTkfLkr01Mwhw1tfccpHty9VzfG6V7atGYG92aacxEeU7JDryXNTudx92D5SPmp7y3m07t9L6zOF480HZXQabtxdsH7zenMbfWHh63xqDagu4AA9eXvPqo7MUAMjx3CZkXLT+No87jcGNbqk7OGXEpRe33X+onYzhPw6radNpdSrSaWUTlOppgSGtFy6TLnTuQSq/E4GBIVpgcWGh2GrH+G6wdPyZtHA//GRN9NdpUt9Bzgc8fEYQ2oLnWclS9yHQb8wZ1C6XZ4uTE8T52fByhtqomLeIKv8AGYDcei57iNMggac+nX8/JHAo+5lFhGTXceo+gH5Lq6NfLldyOU/0vgf/AKy+Urn8FR/ivPUeXT8vJWrxJfT5sHvmE+wUyds9jpo6YFnxnBCvTt87bsPX8PgUdn+JmrSLXfOyWkHWyXDsTma0ncCeh3HqomNp/ArtxLfkqENqjk46O8/r4qUapK0dthMeHsBaZEC3jqo+OqCo0jfz+oVbwuW1cgPddLm++YfQ+auDhyPddU7PnMuP05uLMzTY3I/KGghoLoAsefTRByvcQQCN9PJKjcUh00ttmmfT3WPD2EsdE94wDEmOd/H2QQQnsJDnXdBysEl07ADXXTwC3fHc1t7bAN7xtqGxYCZ7x0U11D7plrAIscpJ5l2v0UGs8OOVtmjUgT5T9T77JiIOIfmc1r9ZLjB0ItE76rn+31aKLGDQ1BPgGuP1hXAdmqk7Nt+Z/JbMXwiligKVUO1lrmmHNOVwkbG5aIIIVJqO7Hpc1pXc8qQtuMohlR9MHMGPe0O0zBri0OjaYlaVtTswtU6GhJNMASQhIDSEwhCYEjB4V1R2VtgLucdGjmf0WzF8QDGmlQlrSO+/71TxOzegshC4v3Sp9jTfp4lKPLK/DUy9y7PhGHDGjqhCzZ32PZ+mwVau5d03Lex6aFlPaRvpvW9rkIQDNgKylCFSIYE+ap+N4QhoqNvlPSwj706gxE+HUoQgiXBD7OY1rahpg9xxHSM3j1j1VljKGU9NR43t628xshCT2Zzg26MMN3h8M2c0E0yd26mmfWRvprABm8M4lkc0OuGy2CYhujqTjsBFj90gHQWELp/zZmnijKUoPhq/sy3xOHFnNOZrrgxEieWxEEEbEEbLj+K96sWiLQPMxc+Eg+qEIyP2nldKrn9ivwTB8R5bpmEdGgDL5xB81tqu/jDq0j0yn8yhClHt4/gjfgXRmbyeSPBwzfUkKe/K5pY4S1wgjmEIQdkSODU5aRmJqUXANFpc2AWk88wOW288l0lbENe1jw9jQ6Mpe4MBlzWCJ/me0eYQhVHg8X6htOzTg3UzkjEUbNeGyXgEvDHtOYt0h/1GoIGyg+nlYGVqU5RHfAMljqhljoI7rHEzcBt4QhQpts81yZurtcxuUm55CNRNgIgQqrFODGxz1800LrF2UnaKrAfKXcyT+iyxHEhQpVa1pYzuz+IkZR/llQhU1ezO16XaPLD1N/qd0kIW884SYKEIAEJIQB//2Q==',
      details: 'A brilliant bilingual speaker, Swaraj enjoyed the cut and thrust of parliamentary debates'
    },
    {
      title: 'Received fake ticket from Jet Airways, Goibibo after flight cancellation',
      img: 'https://akm-img-a-in.tosshub.com/indiatoday/images/story/201904/screengrab_jetGoibibo.png?HKeMJq35HGpi2Sqbx9tOB7dVRrhiMosu',
      details: 'A flier claimed that she was deceived by Jet Airways and Goibibo after her Jet Airways flight was cancelled and in return, she was given a fake British Airways ticket as an alternate.'
    },
    {
      title: 'RBI bids for Air India s iconic Nariman Point tower',
      img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRe4BnPlkaICizbbuHaPFFDGnBdQYDvaj523Pj02yFlTu0Ene9',
      details: 'Reserve Bank of India (RBI) has shown interest in taking over of Air India iconic tower at Nariman Point in Mumbai'
    },
    {
      title: 'New guidelines to tackle mental health of inmates',
      img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRgFnD9ox1ibf_ps54fAbmfUU6g1rVAZqFOC5BGwKnYSpKRgXWHyg',
      details: 'At present, only Pennsylvania has constituted a detailed manual on mental health for prisoners. Dr Nand Kumar, professor of psychiatry at AIIMS has framed these guidelines on mental health condition for prisoners.Talking to Mail Today, Ajoy Kashyap, DG of Jail (Delhi) said: We are continuously giving sensitizing training to our volunteers and counselors about the mental health issues in Tihar jail for the past one year. But there was no manual as such AIIMS doctors have helped us to develop first ever manual for prisoners mental health condition with an aim to decrease suicide rate in Tihar'
    },
    {
      title: 'Modi government',
      img: 'https://cdn.pixabay.com/photo/2019/07/25/08/53/modi-4362086__340.jpg',
      details: 'According to home ministry officials, a joint coordination committee, formed only last month under NCB director general Rakesh Asthana, met on Wednesday for the first time to discuss ways to curb the drug trade.'
    }
  ]

  constructor() { }

  sendNews(n){
    this.nData=n;
    console.log(n);
  }

  ngOnInit() {
  }

}
