import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { CarsComponent } from './cars/cars.component';
import { RecipesComponent } from './recipes/recipes.component';
import { NewsComponent } from './news/news.component';
import { MobilesComponent } from './mobiles/mobiles.component';
import { CarsDetailsComponent } from './cars-details/cars-details.component';
import { RecipesDetailsComponent } from './recipes-details/recipes-details.component';
import { MobilesDetailsComponent } from './mobiles-details/mobiles-details.component';
import { NewsDetailsComponent } from './news-details/news-details.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CarsComponent,
    RecipesComponent,
    NewsComponent,
    MobilesComponent,
    CarsDetailsComponent,
    RecipesDetailsComponent,
    MobilesDetailsComponent,
    NewsDetailsComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([
      { path:'cars', component: CarsComponent},
      { path:'recipes', component: RecipesComponent},
      { path:'news', component: NewsComponent},
      { path:'mobiles', component: MobilesComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
