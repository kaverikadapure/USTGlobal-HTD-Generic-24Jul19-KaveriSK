import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {

  carData: any='';

  cars = [
    {
      brand: 'Volkswagen',
      img: 'https://www.mbaskool.com/2018_images/top_brands/car_world/car_wrld02.jpg',
      description: 'Volkswagen Group is the second largest manufacturer of the world with its headquarter in Wolfsburg, Lower Saxony, Germany.'
    },
    {
      brand: 'Toyota Motors',
      img: 'https://www.mbaskool.com/2018_images/top_brands/car_world/car_wrld01.jpg',
      description: 'Toyota Motor Corporation is the largest automaker of the world. It is a Japanese multinational firm having a global presence.'
    },
    {
      brand: 'Daimler',
      img: 'https://www.mbaskool.com/2018_images/top_brands/car_world/car_wrld03.jpg',
      description: 'Daimler AG is one of the world’s biggest producer and supplier of premium cars and commercial vehicles all around the world.'
    },
    {
      brand: 'Ford Motor',
      img: 'https://www.mbaskool.com/2018_images/top_brands/car_world/car_wrld05.jpg',
      description: 'Ford Motor Company is an American multinational automaker incorporated in Delaware in the year 1919.'
    },
    {
      brand: 'General Motors',
      img: 'https://www.mbaskool.com/2018_images/top_brands/car_world/car_wrld04.jpg',
      description: 'General Motors is a global automotive company established in the year 1908.'
    },
    {
      brand: 'Honda Motor',
      img: 'https://www.mbaskool.com/2018_images/top_brands/car_world/car_wrld06.jpg',
      description: 'Honda Motor Company is a Japanese multinational automotive and motorcycle company with its presence all around the globe.'
    },
    {
      brand: 'SAIC Motor',
      img: 'https://www.mbaskool.com/2018_images/top_brands/car_world/car_wrld07.jpg',
      description: 'SAIC Motor Corporation Limited is the largest Chinese automaker enlisted in the Fortune 500 Global list.'
    },
    {
      brand: 'Fiat Chrysler',
      img: 'https://www.mbaskool.com/2018_images/top_brands/car_world/car_wrld10.jpg',
      description: 'Fiat Chrysler Automobiles (FCA) is one of the leading car brands in the world.'
    },
    {
      brand: 'BMW group',
      img: 'https://www.mbaskool.com/2018_images/top_brands/car_world/car_wrld08.jpg',
      description: 'BMW group abbreviated as Bayerische Motoren Werke Group is one of the leading manufacturers of premium automobiles and motorcycles and one of the top car brands in the world.'
    },
    {
      brand: 'Nissan Motor',
      img: 'https://www.mbaskool.com/2018_images/top_brands/car_world/car_wrld09.jpg',
      description: 'Nissan Motor Corporation is a Japanese automaker having been established in the year 1933 at the Yokohama city in Japan.'
    }
  ]

  constructor() { }

  sendCar(car){
    this.carData=car;
    console.log(car);
  }

  ngOnInit() {
  }

}
