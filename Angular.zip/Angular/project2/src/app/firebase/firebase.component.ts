import { Component, OnInit } from '@angular/core';
import { FirebaseService } from '../firebase.service';
import { NgForm } from '@angular/forms';
import { Router} from '@angular/router';

@Component({
  selector: 'app-firebase',
  templateUrl: './firebase.component.html',
  styleUrls: ['./firebase.component.css']
})
export class FirebaseComponent implements OnInit {

  constructor(private firebaseService: FirebaseService,
    private router : Router) { }

    postUser(userform : NgForm) {
   if(userform.value.id){
     this.firebaseService.updateData(userform.value).subscribe(data => {
       console.log(data);
       this.firebaseService.getData();
       userform.reset();
       this.router.navigateByUrl('/user');
     }, err =>{
       console.log(err);
     });
   }else {
    this.firebaseService.postData(userform.value).subscribe(data => {
      console.log(data);
      this.firebaseService.getData();
      userform.reset();
      this.router.navigateByUrl('/user');
    }, err => {
      console.log(err);
    });
  }
  }

  ngOnInit() {
  }

}
