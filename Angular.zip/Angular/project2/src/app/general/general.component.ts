import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.css']
})
export class GeneralComponent implements OnInit {

  gn : any[] = [];

  constructor(private http: HttpClient) {
    http.get<any>('https://newsapi.org/v2/top-headlines?category=general&apiKey=090ad968f7214e81af4c6485d767aca2')
    .subscribe(resData =>{
      this.gn = resData.articles;
      console.log(this.gn);
    })
   }

  ngOnInit() {
  }

}
