import { Component, OnInit } from '@angular/core';
import { AssoService } from '../asso.service';

@Component({
  selector: 'app-asso',
  templateUrl: './asso.component.html',
  styleUrls: ['./asso.component.css']
})
export class AssoComponent implements OnInit {

  constructor(public assoService: AssoService) { }

  ngOnInit() {
    this.assoService.getData();
  }

}
