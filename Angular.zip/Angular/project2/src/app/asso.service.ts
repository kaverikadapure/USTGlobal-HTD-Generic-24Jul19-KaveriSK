import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AssoService {

  things: any[] = [];

  constructor(private http: HttpClient) { }

  getData() {
    this.http.get(`http://jsonplaceholder.typicode.com/posts`).pipe(map(resData => {
      let usersArray =[];
      for(let key in resData) {
        usersArray.push({...resData[key], id:key});
        console.log(usersArray);
      }
      return usersArray;
    })).subscribe(data =>{
      this.things = data;
      console.log(data);
    }, err => {
      console.log(err);
    });
}

}
