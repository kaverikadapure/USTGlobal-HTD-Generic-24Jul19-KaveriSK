import { Component, OnInit } from '@angular/core';
import { AssiService } from '../assi.service';

@Component({
  selector: 'app-assi',
  templateUrl: './assi.component.html',
  styleUrls: ['./assi.component.css']
})
export class AssiComponent implements OnInit {
  
  constructor(public assiService: AssiService) { }

  ngOnInit() {
    this.assiService.getData();
  }

}
