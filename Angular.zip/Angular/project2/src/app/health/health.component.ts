import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-health',
  templateUrl: './health.component.html',
  styleUrls: ['./health.component.css']
})
export class HealthComponent implements OnInit {

  health : any[] = [];

  constructor(private http: HttpClient) {
    http.get<any>('https://newsapi.org/v2/top-headlines?category=health&apiKey=090ad968f7214e81af4c6485d767aca2')
    .subscribe(resData =>{
      this.health = resData.articles;
      console.log(this.health);
    })
   }

  ngOnInit() {
  }

}
