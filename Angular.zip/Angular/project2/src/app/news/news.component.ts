import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  indianNews : any[] = [];

  constructor(private http: HttpClient) {
    http.get<any>('https://newsapi.org/v2/top-headlines?country=in&apiKey=090ad968f7214e81af4c6485d767aca2')
    .subscribe(resData =>{
      this.indianNews = resData.articles;
      console.log(this.indianNews);
    })
   }

  ngOnInit() {
  }

}
