import { Injectable } from '@angular/core';

@Injectable({
    providedIn: "root"
})

export class UserService {
  printDetails() {
    throw new Error("Method not implemented.");
  }
    user = [
        {
            name: 'Prem',
            company: 'Greet Technologies'
        },
        {
            name: 'Harsh',
            company: 'Greet Technologies'
        },
        {
            name: 'Kaveri',
            company: 'UST Global'
        }
    ]
}