import { ElementRef, HostListener, HostBinding } from '@angular/core';

import { Directive } from '@angular/core';

@Directive({
  selector: '[appMyDirective]'
})
export class MyDirectiveDirective {

  constructor(private elementRef: ElementRef) {
    elementRef.nativeElement.style.backgroundColor = 'purple';
    elementRef.nativeElement.style.Color = 'black';
    elementRef.nativeElement.style.padding = "50px";
   }

   @HostBinding('style.background') background: string;
   @HostListener('mouseenter')
   mouseEnter(){
     this.background= "yellow";
     //console.log('mouse entered');
     //alert('mouse enter');
    //  this.elementRef.nativeElement.style.backgroundColor= 'black';
    //  this.elementRef.nativeElement.style.color= 'white';
    //  this.elementRef.nativeElement.style.fontSize= '40px';
   }

  
   @HostListener('mouseleave')
   mouseLeave(){
     this.background= "blue";
     //console.log('mouse entered');
     //alert('mouse enter');
    //  this.elementRef.nativeElement.style.backgroundColor= 'green';
    //  this.elementRef.nativeElement.style.color= 'red';
    //  this.elementRef.nativeElement.style.fontSize= '80px';

   }


}
