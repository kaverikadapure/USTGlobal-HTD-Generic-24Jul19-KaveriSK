import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {
  condition = false;
 users =[
   { 
     id : 123,
     name : 'abc',
     city : 'bgm'
   },
   { 
    id : 234,
    name : 'pqr',
    city : 'lkm'
  },
  { 
    id : 345,
    name : 'xyz',
    city : 'byt'
  },
  { 
    id : 456,
    name : 'ghj',
    city : 'rty'
  },
  { 
    id : 567,
    name : 'iyu',
    city : 'opi'
  }
 ]
  constructor() { }

  removeUser(user){
    let index = this.users.indexOf(user);
    this.users.splice(index, 1);
    this.condition=true;
  }

  remove(){
    this.condition=false;
  }
  ngOnInit() {
  }

}
