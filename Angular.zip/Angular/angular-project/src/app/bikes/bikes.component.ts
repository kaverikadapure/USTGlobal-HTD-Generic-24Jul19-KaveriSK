import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bikes',
  templateUrl: './bikes.component.html',
  styleUrls: ['./bikes.component.css']
})
export class BikesComponent implements OnInit {

  bikeData: any='';

  bikes = [
    {
      brand : 'KTM',
      img : 'https://cdn.pixabay.com/photo/2017/08/13/13/14/motorcycle-2637088__340.jpg',
      description : 'The 2017 edition of the KTM RC 390 was recently launched in January, 2017. The new KTM RC 390 gets cosmetic updates and new features. It now gets a black and orange colour scheme, but with fresh graphic design in white. The body of the bike have orange-coloured panels which were previously used only for the trellis frame and alloy wheels. The 2017 KTM RC 390 has been priced at Rs 2.25 lakh, ex-showroom, Delhi.'
    },
    {
      brand : 'Royal Enfield',
      img : 'https://cdn.pixabay.com/photo/2017/11/23/04/08/royal-enfield-2972008__340.jpg',
      description : 'In the Classic, heritage and time-tested performance go hand in hand. Its dashing, vintage-inspired looks are underscored by an Enfield trademark - dependability.The Classic is a machine you can count on, come hill, dale or plain. It has the torque to flatten mountains and persevere through entire ranges'
    },
    {
      brand : 'TVS Appachi',
      img : 'https://cdn.pixabay.com/photo/2017/12/29/05/58/sport-3046819__340.jpg',
      description : 'TVS has officially launched the Apache RTR 160 4V. TVS offers 5 Apache models in India. TVS Apache RTR 160 is the lowest priced model at Rs. 78,715 (Ex-Showroom, Delhi) and New TVS Apache RR 310 is the highest priced model at Rs. 2.17 lakh (Ex-Showroom, Delhi).'
    },
    {
      brand : 'Honda',
      img : 'https://cdn.pixabay.com/photo/2016/06/13/08/56/motorcycle-1453863__340.jpg',
      description : 'Honda New Bikes Model List in India. Honda Activa 5G. Top Selling Scooter in May 19 Rs Honda CB Shine. 3rd Most Selling Bike in May19. Rs. Honda Dio. Rs. 53,218 Onwards. '
    },
    {
      brand : 'Dominar',
      img : 'https://cdn.pixabay.com/photo/2014/12/16/03/37/motor-cycle-569865__340.jpg',
      description : 'The Bajaj Dominar 400 has received a price hike of around Rs 5,800. It now retails at Rs 1.80 lakh (ex-showroom Delhi). The 2019 Bajaj Dominar 400 has been spotted with a new metallic red paint scheme, hinting at an imminent launch.'
    }
  ]
  constructor() { }

  sendBike(bike){
    this.bikeData = bike;
    console.log(bike);
  }

  ngOnInit() {
  }

}
