import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent {
redColor=true;
 name = 'kavi';
 textClasses='bg-success text-white';
 paragraphStyle =true;
 padding = '50px';
 columnSpan= 2;
 imgURl='https://cdn.pixabay.com/photo/2017/10/25/16/51/tree-2888513__340.jpg';
 
 constructor(){
  setTimeout(()=>{
      this.redColor = false;
      this.paragraphStyle=false;
    },5000)
 }
}
